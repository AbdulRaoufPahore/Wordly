class WordModel {
  final String word;
  final List<Meaning> meanings;
  final List<Phonetic> phonetics;
  final String? origin;

  WordModel({
    required this.word,
    required this.meanings,
    required this.phonetics,
    this.origin,
  });

  factory WordModel.fromJson(Map<String, dynamic> json) {
    return WordModel(
      word: json['word'] ?? '',
      meanings: (json['meanings'] as List?)
          ?.map((m) => Meaning.fromJson(m))
          .toList() ?? [],
      phonetics: (json['phonetics'] as List?)
          ?.map((p) => Phonetic.fromJson(p))
          .toList() ?? [],
      origin: json['origin'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'word': word,
      'meanings': meanings.map((m) => m.toJson()).toList(),
      'phonetics': phonetics.map((p) => p.toJson()).toList(),
      'origin': origin,
    };
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    return other is WordModel && other.word == word;
  }

  @override
  int get hashCode => word.hashCode;
}

class Meaning {
  final String partOfSpeech;
  final List<Definition> definitions;
  final List<String> synonyms;
  final List<String> antonyms;

  Meaning({
    required this.partOfSpeech,
    required this.definitions,
    required this.synonyms,
    required this.antonyms,
  });

  factory Meaning.fromJson(Map<String, dynamic> json) {
    return Meaning(
      partOfSpeech: json['partOfSpeech'] ?? '',
      definitions: (json['definitions'] as List?)
          ?.map((d) => Definition.fromJson(d))
          .toList() ?? [],
      synonyms: List<String>.from(json['synonyms'] ?? []),
      antonyms: List<String>.from(json['antonyms'] ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'partOfSpeech': partOfSpeech,
      'definitions': definitions.map((d) => d.toJson()).toList(),
      'synonyms': synonyms,
      'antonyms': antonyms,
    };
  }
}

class Definition {
  final String definition;
  final String? example;
  final List<String> synonyms;
  final List<String> antonyms;

  Definition({
    required this.definition,
    this.example,
    required this.synonyms,
    required this.antonyms,
  });

  factory Definition.fromJson(Map<String, dynamic> json) {
    return Definition(
      definition: json['definition'] ?? '',
      example: json['example'],
      synonyms: List<String>.from(json['synonyms'] ?? []),
      antonyms: List<String>.from(json['antonyms'] ?? []),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'definition': definition,
      'example': example,
      'synonyms': synonyms,
      'antonyms': antonyms,
    };
  }
}

class Phonetic {
  final String? text;
  final String? audio;

  Phonetic({
    this.text,
    this.audio,
  });

  factory Phonetic.fromJson(Map<String, dynamic> json) {
    return Phonetic(
      text: json['text'],
      audio: json['audio'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'text': text,
      'audio': audio,
    };
  }
}