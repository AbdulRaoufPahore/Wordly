import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../viewmodels/history_viewmodel.dart';
import '../viewmodels/home_viewmodel.dart';
import '../viewmodels/word_detail_viewmodel.dart';
import '../widgets/loading_widget.dart';

class HistoryView extends StatefulWidget {
  const HistoryView({super.key});

  @override
  State<HistoryView> createState() => _HistoryViewState();
}

class _HistoryViewState extends State<HistoryView> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<HistoryViewModel>().loadHistory();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Search History'),
        backgroundColor: Theme.of(context).colorScheme.primary,
        foregroundColor: Colors.white,
        actions: [
          Consumer<HistoryViewModel>(
            builder: (context, viewModel, child) {
              if (viewModel.history.isEmpty) return const SizedBox.shrink();

              return PopupMenuButton(
                icon: const Icon(Icons.more_vert, color: Colors.white),
                itemBuilder: (context) => [
                  PopupMenuItem(
                    child: const Text('Clear All'),
                    onTap: () => _showClearConfirmation(),
                  ),
                ],
              );
            },
          ),
        ],
      ),
      body: Consumer<HistoryViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.isLoading) {
            return const Center(child: LoadingWidget());
          }

          if (viewModel.history.isEmpty) {
            return _buildEmptyState();
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: viewModel.history.length,
            itemBuilder: (context, index) {
              final word = viewModel.history[index];
              return _buildHistoryItem(word, index);
            },
          );
        },
      ),
    );
  }

  Widget _buildHistoryItem(String word, int index) {
    return Card(
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            Icons.history,
            color: Theme.of(context).colorScheme.primary,
          ),
        ),
        title: Text(
          word,
          style: const TextStyle(
            fontWeight: FontWeight.w600,
            fontSize: 16,
          ),
        ),
        subtitle: Text(
          'Tap to search again',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
          ),
        ),
        trailing: IconButton(
          onPressed: () => _removeFromHistory(word),
          icon: Icon(
            Icons.close,
            color: Theme.of(context).colorScheme.error,
          ),
        ),
        onTap: () => _searchWord(word),
      ),
    )
        .animate()
        .fadeIn(
          delay: (index * 100).ms,
          duration: 600.ms,
        )
        .slideX(begin: 0.3);
  }

  Widget _buildEmptyState() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.history,
              size: 80,
              color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
            ).animate().scale(duration: 800.ms),
            const SizedBox(height: 24),
            Text(
              'No Search History',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.7),
                  ),
            ).animate().fadeIn(delay: 200.ms, duration: 600.ms),
            const SizedBox(height: 16),
            Text(
              'Your search history will appear here as you search for words.',
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6),
                  ),
            ).animate().fadeIn(delay: 400.ms, duration: 600.ms),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: () => Navigator.pop(context),
              icon: const Icon(Icons.search),
              label: const Text('Start Searching'),
            )
                .animate()
                .fadeIn(delay: 600.ms, duration: 600.ms)
                .scale(begin: Offset(0.8, 0.8)),
          ],
        ),
      ),
    );
  }

  Future<void> _searchWord(String word) async {
    try {
      final results = await context.read<HomeViewModel>().searchWord(word);
      if (results.isNotEmpty && mounted) {
        await context.read<WordDetailViewModel>().setCurrentWord(results.first);
        if (mounted) {
          Navigator.pushNamed(context, '/word-detail');
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
                'Error searching for "$word": ${e.toString().replaceAll('Exception: ', '')}'),
            backgroundColor: Theme.of(context).colorScheme.error,
          ),
        );
      }
    }
  }

  Future<void> _removeFromHistory(String word) async {
    await context.read<HistoryViewModel>().removeFromHistory(word);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$word removed from history'),
          backgroundColor: Theme.of(context).colorScheme.primary,
        ),
      );
    }
  }

  void _showClearConfirmation() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Search History'),
        content: const Text(
            'Are you sure you want to clear all search history? This action cannot be undone.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              context.read<HistoryViewModel>().clearHistory();
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: const Text('Search history cleared'),
                  backgroundColor: Theme.of(context).colorScheme.primary,
                ),
              );
            },
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }
}
