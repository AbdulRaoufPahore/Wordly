import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../viewmodels/word_detail_viewmodel.dart';
import '../models/word_model.dart';
import '../widgets/loading_widget.dart';

class WordDetailView extends StatefulWidget {
  const WordDetailView({super.key});

  @override
  State<WordDetailView> createState() => _WordDetailViewState();
}

class _WordDetailViewState extends State<WordDetailView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<WordDetailViewModel>(
        builder: (context, viewModel, child) {
          if (viewModel.currentWord == null) {
            return const Center(child: LoadingWidget());
          }

          return CustomScrollView(
            slivers: [
              _buildSliverAppBar(viewModel),
              SliverToBoxAdapter(
                child: _buildContent(viewModel.currentWord!),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildSliverAppBar(WordDetailViewModel viewModel) {
    return SliverAppBar(
      expandedHeight: 200,
      pinned: true,
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          viewModel.currentWord?.word ?? '',
          style: const TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.primary.withOpacity(0.8),
              ],
            ),
          ),
        ),
      ),
      actions: [
        IconButton(
          onPressed: viewModel.isLoading ? null : viewModel.toggleFavorite,
          icon: Icon(
            viewModel.isFavorite ? Icons.favorite : Icons.favorite_border,
            color: Colors.white,
          ),
        ).animate().scale(duration: 300.ms),
      ],
    );
  }

  Widget _buildContent(WordModel word) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (word.phonetics.isNotEmpty) _buildPhonetics(word.phonetics),
          const SizedBox(height: 24),
          _buildMeanings(word.meanings),
          if (word.origin != null) ...[
            const SizedBox(height: 24),
            _buildOrigin(word.origin!),
          ],
        ],
      ),
    );
  }

  Widget _buildPhonetics(List<Phonetic> phonetics) {
    final phoneticText = phonetics
        .where((p) => p.text != null && p.text!.isNotEmpty)
        .map((p) => p.text!)
        .join(', ');

    if (phoneticText.isEmpty) return const SizedBox.shrink();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Icon(
              Icons.volume_up,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                phoneticText,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2);
  }

  Widget _buildMeanings(List<Meaning> meanings) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: meanings.asMap().entries.map((entry) {
        final index = entry.key;
        final meaning = entry.value;
        
        return _buildMeaningCard(meaning, index);
      }).toList(),
    );
  }

  Widget _buildMeaningCard(Meaning meaning, int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildPartOfSpeech(meaning.partOfSpeech),
            const SizedBox(height: 16),
            _buildDefinitions(meaning.definitions),
            if (meaning.synonyms.isNotEmpty) ...[
              const SizedBox(height: 16),
              _buildSynonymsAntonyms('Synonyms', meaning.synonyms, Colors.green),
            ],
            if (meaning.antonyms.isNotEmpty) ...[
              const SizedBox(height: 16),
              _buildSynonymsAntonyms('Antonyms', meaning.antonyms, Colors.red),
            ],
          ],
        ),
      ),
    ).animate().fadeIn(
      delay: (index * 200).ms,
      duration: 600.ms,
    ).slideX(begin: 0.3);
  }

  Widget _buildPartOfSpeech(String partOfSpeech) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Theme.of(context).colorScheme.primary.withOpacity(0.3),
        ),
      ),
      child: Text(
        partOfSpeech,
        style: TextStyle(
          color: Theme.of(context).colorScheme.primary,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _buildDefinitions(List<Definition> definitions) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: definitions.asMap().entries.map((entry) {
        final index = entry.key;
        final definition = entry.value;
        
        return Padding(
          padding: EdgeInsets.only(bottom: index < definitions.length - 1 ? 16 : 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: const EdgeInsets.only(top: 6, right: 12),
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
                  Expanded(
                    child: Text(
                      definition.definition,
                      style: Theme.of(context).textTheme.bodyLarge,
                    ),
                  ),
                ],
              ),
              if (definition.example != null) ...[
                const SizedBox(height: 8),
                Padding(
                  padding: const EdgeInsets.only(left: 18),
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceVariant.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(8),
                      border: Border(
                        left: BorderSide(
                          color: Theme.of(context).colorScheme.primary,
                          width: 3,
                        ),
                      ),
                    ),
                    child: Text(
                      '"${definition.example}"',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildSynonymsAntonyms(String title, List<String> words, Color color) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: color,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: words.map((word) {
            return Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withOpacity(0.3)),
              ),
              child: Text(
                word,
                style: TextStyle(
                  color: color,
                  fontSize: 12,
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildOrigin(String origin) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.history_edu,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Origin',
                  style: Theme.of(context).textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              origin,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 600.ms).slideY(begin: 0.2);
  }
}