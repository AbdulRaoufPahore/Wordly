import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../viewmodels/home_viewmodel.dart';
import '../viewmodels/word_detail_viewmodel.dart';
import '../viewmodels/theme_viewmodel.dart';
import '../widgets/search_bar_widget.dart';
import '../widgets/suggestion_list_widget.dart';
import '../widgets/loading_widget.dart';

class HomeView extends StatefulWidget {
  const HomeView({super.key});

  @override
  State<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  late TextEditingController _searchController;
  late FocusNode _searchFocusNode;

  @override
  void initState() {
    super.initState();
    _searchController = TextEditingController();
    _searchFocusNode = FocusNode();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Theme.of(context).colorScheme.primary,
              Theme.of(context).colorScheme.primary.withOpacity(0.8),
              Theme.of(context).colorScheme.surface,
            ],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              _buildSearchSection(),
              Expanded(child: _buildContent()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            'Wordly',
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
          ).animate().fadeIn(duration: 600.ms).slideX(begin: -0.3),
          Row(
            children: [
              Consumer<ThemeViewModel>(
                builder: (context, themeViewModel, child) {
                  return IconButton(
                    onPressed: () {
                      final currentMode = themeViewModel.themeMode;
                      final newMode = currentMode == ThemeMode.light
                          ? ThemeMode.dark
                          : ThemeMode.light;
                      themeViewModel.setThemeMode(newMode);
                    },
                    icon: Icon(
                      themeViewModel.themeMode == ThemeMode.light
                          ? Icons.dark_mode
                          : Icons.light_mode,
                      color: Colors.white,
                    ),
                  );
                },
              ),
              IconButton(
                onPressed: () => Navigator.pushNamed(context, '/favorites'),
                icon: const Icon(Icons.favorite, color: Colors.white),
              ).animate().fadeIn(delay: 200.ms, duration: 600.ms),
              IconButton(
                onPressed: () => Navigator.pushNamed(context, '/history'),
                icon: const Icon(Icons.history, color: Colors.white),
              ).animate().fadeIn(delay: 400.ms, duration: 600.ms),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildSearchSection() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          SearchBarWidget(
            controller: _searchController,
            focusNode: _searchFocusNode,
            onChanged: (query) {
              context.read<HomeViewModel>().updateSearchQuery(query);
            },
            onSubmitted: _handleSearch,
          )
              .animate()
              .fadeIn(delay: 600.ms, duration: 600.ms)
              .slideY(begin: 0.3),
          const SizedBox(height: 16),
        ],
      ),
    );
  }

  Widget _buildContent() {
    return Container(
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
      ),
      child: ClipRRect(
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        child: Consumer<HomeViewModel>(
          builder: (context, viewModel, child) {
            switch (viewModel.searchState) {
              case SearchState.searching:
                return const Center(child: LoadingWidget());
              case SearchState.success:
                if (viewModel.suggestions.isNotEmpty) {
                  return SuggestionListWidget(
                    suggestions: viewModel.suggestions,
                    onSuggestionTap: _handleSearch,
                    searchQuery: viewModel.searchQuery,
                  );
                }
                return _buildWelcomeContent();
              case SearchState.error:
                return _buildErrorContent(viewModel.errorMessage);
              default:
                return _buildWelcomeContent();
            }
          },
        ),
      ),
    );
  }

  Widget _buildWelcomeContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Welcome to Wordly!',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ).animate().fadeIn(delay: 800.ms, duration: 600.ms),
          const SizedBox(height: 16),
          Text(
            'Search for any English word to discover its meanings, pronunciations, and usage examples.',
            style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                  color:
                      Theme.of(context).colorScheme.onSurface.withOpacity(0.7),
                ),
          ).animate().fadeIn(delay: 1000.ms, duration: 600.ms),
          const SizedBox(height: 32),
          _buildFeatureCards(),
        ],
      ),
    );
  }

  Widget _buildFeatureCards() {
    final features = [
      {
        'icon': Icons.search,
        'title': 'Smart Search',
        'description': 'Find words with intelligent auto-suggestions',
      },
      {
        'icon': Icons.favorite,
        'title': 'Favorites',
        'description': 'Save words you want to remember',
      },
      {
        'icon': Icons.history,
        'title': 'History',
        'description': 'Track your search history',
      },
    ];

    return Column(
      children: features.asMap().entries.map((entry) {
        final index = entry.key;
        final feature = entry.value;

        return Card(
          child: ListTile(
            leading: Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                feature['icon'] as IconData,
                color: Theme.of(context).colorScheme.primary,
              ),
            ),
            title: Text(
              feature['title'] as String,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(feature['description'] as String),
          ),
        )
            .animate()
            .fadeIn(
              delay: (1200 + (index * 200)).ms,
              duration: 600.ms,
            )
            .slideX(begin: 0.3);
      }).toList(),
    );
  }

  Widget _buildErrorContent(String error) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.error_outline,
              size: 64,
              color: Theme.of(context).colorScheme.error,
            ).animate().scale(duration: 600.ms),
            const SizedBox(height: 16),
            Text(
              'Oops!',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.error,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 8),
            Text(
              error,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyLarge,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                context.read<HomeViewModel>().clearSearch();
                _searchController.clear();
              },
              child: const Text('Try Again'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _handleSearch(String word) async {
    if (word.trim().isEmpty) return;

    _searchFocusNode.unfocus();

    try {
      final results = await context.read<HomeViewModel>().searchWord(word);
      if (results.isNotEmpty && mounted) {
        await context.read<WordDetailViewModel>().setCurrentWord(results.first);
        if (mounted) {
          Navigator.pushNamed(context, '/word-detail');
        }
      }
    } catch (e) {
      // Error is handled in the viewmodel
    }
  }
}
