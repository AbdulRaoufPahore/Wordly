import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../../models/word_model.dart';

class StorageService {
  static StorageService? _instance;
  static StorageService get instance => _instance ??= StorageService._();
  StorageService._();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  // Favorites
  Future<void> addToFavorites(WordModel word) async {
    final favorites = await getFavorites();
    if (!favorites.any((fav) => fav.word == word.word)) {
      favorites.add(word);
      await _saveFavorites(favorites);
    }
  }

  Future<void> removeFromFavorites(String word) async {
    final favorites = await getFavorites();
    favorites.removeWhere((fav) => fav.word == word);
    await _saveFavorites(favorites);
  }

  Future<List<WordModel>> getFavorites() async {
    final String? favoritesJson = _prefs?.getString('favorites');
    if (favoritesJson == null) return [];
    
    final List<dynamic> favoritesList = json.decode(favoritesJson);
    return favoritesList.map((json) => WordModel.fromJson(json)).toList();
  }

  Future<bool> isFavorite(String word) async {
    final favorites = await getFavorites();
    return favorites.any((fav) => fav.word == word);
  }

  Future<void> _saveFavorites(List<WordModel> favorites) async {
    final String favoritesJson = json.encode(
      favorites.map((word) => word.toJson()).toList(),
    );
    await _prefs?.setString('favorites', favoritesJson);
  }

  // History
  Future<void> addToHistory(String word) async {
    final history = await getHistory();
    history.removeWhere((item) => item == word); // Remove if exists
    history.insert(0, word); // Add to beginning
    
    // Keep only last 50 items
    if (history.length > 50) {
      history.removeRange(50, history.length);
    }
    
    await _saveHistory(history);
  }

  Future<List<String>> getHistory() async {
    return _prefs?.getStringList('history') ?? [];
  }

  Future<void> removeFromHistory(String word) async {
    final history = await getHistory();
    history.remove(word);
    await _saveHistory(history);
  }

  Future<void> clearHistory() async {
    await _prefs?.setStringList('history', []);
  }

  Future<void> _saveHistory(List<String> history) async {
    await _prefs?.setStringList('history', history);
  }

  // Theme
  Future<void> setThemeMode(String themeMode) async {
    await _prefs?.setString('theme_mode', themeMode);
  }

  String getThemeMode() {
    return _prefs?.getString('theme_mode') ?? 'system';
  }
}