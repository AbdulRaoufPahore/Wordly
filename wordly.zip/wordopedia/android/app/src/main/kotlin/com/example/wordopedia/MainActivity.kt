package com.example.wordopedia

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
