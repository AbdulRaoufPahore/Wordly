import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class SuggestionListWidget extends StatelessWidget {
  final List<String> suggestions;
  final Function(String) onSuggestionTap;
  final String searchQuery;

  const SuggestionListWidget({
    super.key,
    required this.suggestions,
    required this.onSuggestionTap,
    required this.searchQuery,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: suggestions.length,
      itemBuilder: (context, index) {
        final suggestion = suggestions[index];
        return _buildSuggestionItem(context, suggestion, index);
      },
    );
  }

  Widget _buildSuggestionItem(BuildContext context, String suggestion, int index) {
    return Card(
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(
            Icons.search,
            color: Theme.of(context).colorScheme.primary,
            size: 20,
          ),
        ),
        title: RichText(
          text: TextSpan(
            style: DefaultTextStyle.of(context).style.copyWith(
              fontSize: 16,
              fontWeight: FontWeight.w500,
            ),
            children: _buildHighlightedText(suggestion, searchQuery, context),
          ),
        ),
        subtitle: Text(
          'Tap to search',
          style: TextStyle(
            color: Theme.of(context).colorScheme.onSurface.withOpacity(0.6),
            fontSize: 12,
          ),
        ),
        trailing: Icon(
          Icons.arrow_forward_ios,
          size: 16,
          color: Theme.of(context).colorScheme.onSurface.withOpacity(0.4),
        ),
        onTap: () => onSuggestionTap(suggestion),
      ),
    ).animate().fadeIn(
      delay: (index * 100).ms,
      duration: 600.ms,
    ).slideX(begin: 0.3);
  }

  List<TextSpan> _buildHighlightedText(String text, String query, BuildContext context) {
    if (query.isEmpty) {
      return [TextSpan(text: text)];
    }

    final lowercaseText = text.toLowerCase();
    final lowercaseQuery = query.toLowerCase();
    final queryStart = lowercaseText.indexOf(lowercaseQuery);

    if (queryStart == -1) {
      return [TextSpan(text: text)];
    }

    final beforeMatch = text.substring(0, queryStart);
    final match = text.substring(queryStart, queryStart + query.length);
    final afterMatch = text.substring(queryStart + query.length);

    return [
      if (beforeMatch.isNotEmpty) TextSpan(text: beforeMatch),
      TextSpan(
        text: match,
        style: TextStyle(
          backgroundColor: Theme.of(context).colorScheme.primary.withOpacity(0.2),
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
      if (afterMatch.isNotEmpty) TextSpan(text: afterMatch),
    ];
  }
}