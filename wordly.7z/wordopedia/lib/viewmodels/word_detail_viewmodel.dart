import 'package:flutter/material.dart';
import '../core/services/storage_service.dart';
import '../models/word_model.dart';

class WordDetailViewModel extends ChangeNotifier {
  WordModel? _currentWord;
  bool _isFavorite = false;
  bool _isLoading = false;

  WordModel? get currentWord => _currentWord;
  bool get isFavorite => _isFavorite;
  bool get isLoading => _isLoading;

  Future<void> setCurrentWord(WordModel word) async {
    _currentWord = word;
    _isLoading = true;
    notifyListeners();

    _isFavorite = await StorageService.instance.isFavorite(word.word);
    _isLoading = false;
    notifyListeners();
  }

  Future<void> toggleFavorite() async {
    if (_currentWord == null) return;

    _isFavorite = !_isFavorite;
    notifyListeners();

    if (_isFavorite) {
      await StorageService.instance.addToFavorites(_currentWord!);
    } else {
      await StorageService.instance.removeFromFavorites(_currentWord!.word);
    }
  }

  void clearCurrentWord() {
    _currentWord = null;
    _isFavorite = false;
    _isLoading = false;
    notifyListeners();
  }
}