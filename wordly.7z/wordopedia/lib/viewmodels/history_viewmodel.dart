import 'package:flutter/material.dart';
import '../core/services/storage_service.dart';

class HistoryViewModel extends ChangeNotifier {
  List<String> _history = [];
  bool _isLoading = false;

  List<String> get history => _history;
  bool get isLoading => _isLoading;

  Future<void> loadHistory() async {
    _isLoading = true;
    notifyListeners();

    _history = await StorageService.instance.getHistory();

    _isLoading = false;
    notifyListeners();
  }

  Future<void> removeFromHistory(String word) async {
    await StorageService.instance.removeFromHistory(word);
    _history.remove(word);
    notifyListeners();
  }

  Future<void> clearHistory() async {
    await StorageService.instance.clearHistory();
    _history.clear();
    notifyListeners();
  }
}