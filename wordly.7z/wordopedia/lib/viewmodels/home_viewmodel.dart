import 'package:flutter/material.dart';
import '../core/services/dictionary_service.dart';
import '../core/services/storage_service.dart';
import '../models/word_model.dart';

enum SearchState { idle, searching, success, error }

class HomeViewModel extends ChangeNotifier {
  final DictionaryService _dictionaryService;
  
  SearchState _searchState = SearchState.idle;
  List<String> _suggestions = [];
  String _searchQuery = '';
  String _errorMessage = '';

  SearchState get searchState => _searchState;
  List<String> get suggestions => _suggestions;
  String get searchQuery => _searchQuery;
  String get errorMessage => _errorMessage;

  HomeViewModel({DictionaryService? dictionaryService})
      : _dictionaryService = dictionaryService ?? DictionaryService();

  void updateSearchQuery(String query) {
    _searchQuery = query;
    
    if (query.isEmpty) {
      _suggestions = [];
      _searchState = SearchState.idle;
    } else {
      _suggestions = _dictionaryService.getSuggestions(query);
      _searchState = _suggestions.isNotEmpty ? SearchState.success : SearchState.idle;
    }
    
    notifyListeners();
  }

  Future<List<WordModel>> searchWord(String word) async {
    _searchState = SearchState.searching;
    _errorMessage = '';
    notifyListeners();

    try {
      final results = await _dictionaryService.searchWord(word);
      
      // Add to history
      await StorageService.instance.addToHistory(word);
      
      _searchState = SearchState.success;
      notifyListeners();
      
      return results;
    } catch (e) {
      _searchState = SearchState.error;
      _errorMessage = e.toString().replaceAll('Exception: ', '');
      notifyListeners();
      
      rethrow;
    }
  }

  void clearSearch() {
    _searchQuery = '';
    _suggestions = [];
    _searchState = SearchState.idle;
    _errorMessage = '';
    notifyListeners();
  }
}