import 'package:flutter/material.dart';
import '../core/services/storage_service.dart';
import '../models/word_model.dart';

class FavoritesViewModel extends ChangeNotifier {
  List<WordModel> _favorites = [];
  bool _isLoading = false;

  List<WordModel> get favorites => _favorites;
  bool get isLoading => _isLoading;

  Future<void> loadFavorites() async {
    _isLoading = true;
    notifyListeners();

    _favorites = await StorageService.instance.getFavorites();
    _favorites.sort((a, b) => a.word.compareTo(b.word));

    _isLoading = false;
    notifyListeners();
  }

  Future<void> removeFromFavorites(String word) async {
    await StorageService.instance.removeFromFavorites(word);
    _favorites.removeWhere((fav) => fav.word == word);
    notifyListeners();
  }

  Future<void> clearAllFavorites() async {
    for (final favorite in _favorites) {
      await StorageService.instance.removeFromFavorites(favorite.word);
    }
    _favorites.clear();
    notifyListeners();
  }
}