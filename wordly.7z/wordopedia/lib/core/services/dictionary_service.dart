import 'dart:convert';
import 'package:http/http.dart' as http;
import '../../models/word_model.dart';

class DictionaryService {
  static const String _baseUrl = 'https://api.dictionaryapi.dev/api/v2/entries/en';
  
  Future<List<WordModel>> searchWord(String word) async {
    try {
      final response = await http.get(
        Uri.parse('$_baseUrl/$word'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> jsonData = json.decode(response.body);
        return jsonData.map((json) => WordModel.fromJson(json)).toList();
      } else {
        throw Exception('Word not found');
      }
    } catch (e) {
      throw Exception('Failed to fetch word definition: $e');
    }
  }

  List<String> getSuggestions(String query) {
    // Common English words for suggestions
    final commonWords = [
      'about', 'above', 'abuse', 'actor', 'acute', 'admit', 'adopt', 'adult', 'after', 'again',
      'agent', 'agree', 'ahead', 'alarm', 'album', 'alert', 'alike', 'alive', 'allow', 'alone',
      'along', 'alter', 'amber', 'amid', 'among', 'anger', 'angle', 'angry', 'apart', 'apple',
      'apply', 'arena', 'argue', 'arise', 'array', 'arrow', 'aside', 'asset', 'atlas', 'audio',
      'avoid', 'awake', 'award', 'aware', 'badly', 'baker', 'balls', 'basic', 'batch', 'beach',
      'began', 'begin', 'being', 'below', 'bench', 'billy', 'birth', 'black', 'blame', 'blank',
      'blind', 'block', 'blood', 'board', 'boost', 'booth', 'bound', 'brain', 'brand', 'brass',
      'brave', 'bread', 'break', 'breed', 'brick', 'brief', 'bring', 'broad', 'broke', 'brown',
      'build', 'built', 'buyer', 'cable', 'calif', 'carry', 'catch', 'cause', 'chain', 'chair',
      'chaos', 'charm', 'chart', 'chase', 'cheap', 'check', 'chest', 'chief', 'child', 'china',
      'chose', 'civil', 'claim', 'class', 'clean', 'clear', 'click', 'climb', 'clock', 'close',
      'cloud', 'coach', 'coast', 'could', 'count', 'court', 'cover', 'craft', 'crash', 'crazy',
      'cream', 'crime', 'cross', 'crowd', 'crown', 'crude', 'curve', 'cycle', 'daily', 'dance',
      'dated', 'dealt', 'death', 'debut', 'delay', 'depth', 'doing', 'doubt', 'dozen', 'draft',
      'drama', 'drank', 'drawn', 'dream', 'dress', 'drill', 'drink', 'drive', 'drove', 'dying',
      'eager', 'early', 'earth', 'eight', 'elite', 'empty', 'enemy', 'enjoy', 'enter', 'entry',
      'equal', 'error', 'event', 'every', 'exact', 'exist', 'extra', 'faith', 'false', 'fault',
      'fiber', 'field', 'fifth', 'fifty', 'fight', 'final', 'first', 'fixed', 'flash', 'fleet',
      'floor', 'fluid', 'focus', 'force', 'forth', 'forty', 'forum', 'found', 'frame', 'frank',
      'fraud', 'fresh', 'front', 'fruit', 'fully', 'funny', 'giant', 'given', 'glass', 'globe',
      'going', 'grace', 'grade', 'grand', 'grant', 'grass', 'grave', 'great', 'green', 'gross',
      'group', 'grown', 'guard', 'guess', 'guest', 'guide', 'happy', 'harry', 'heart', 'heavy',
      'hence', 'henry', 'horse', 'hotel', 'house', 'human', 'ideal', 'image', 'index', 'inner',
      'input', 'issue', 'japan', 'jimmy', 'joint', 'jones', 'judge', 'known', 'label', 'large',
      'laser', 'later', 'laugh', 'layer', 'learn', 'lease', 'least', 'leave', 'legal', 'level',
      'lewis', 'light', 'limit', 'links', 'lives', 'local', 'loose', 'lower', 'lucky', 'lunch',
      'lying', 'magic', 'major', 'maker', 'march', 'maria', 'match', 'maybe', 'mayor', 'meant',
      'media', 'metal', 'might', 'minor', 'minus', 'mixed', 'model', 'money', 'month', 'moral',
      'motor', 'mount', 'mouse', 'mouth', 'moved', 'movie', 'music', 'needs', 'never', 'newly',
      'night', 'noise', 'north', 'noted', 'novel', 'nurse', 'occur', 'ocean', 'offer', 'often',
      'order', 'other', 'ought', 'paint', 'panel', 'paper', 'party', 'peace', 'peter', 'phase',
      'phone', 'photo', 'piano', 'piece', 'pilot', 'pitch', 'place', 'plain', 'plane', 'plant',
      'plate', 'point', 'pound', 'power', 'press', 'price', 'pride', 'prime', 'print', 'prior',
      'prize', 'proof', 'proud', 'prove', 'queen', 'quick', 'quiet', 'quite', 'radio', 'raise',
      'range', 'rapid', 'ratio', 'reach', 'ready', 'realm', 'rebel', 'refer', 'relax', 'repay',
      'reply', 'right', 'rigid', 'rival', 'river', 'robin', 'roger', 'roman', 'rough', 'round',
      'route', 'royal', 'rural', 'scale', 'scene', 'scope', 'score', 'sense', 'serve', 'seven',
      'shall', 'shape', 'share', 'sharp', 'sheet', 'shelf', 'shell', 'shift', 'shine', 'shirt',
      'shock', 'shoot', 'short', 'shown', 'sided', 'sight', 'silly', 'since', 'sixth', 'sixty',
      'sized', 'skill', 'sleep', 'slide', 'small', 'smart', 'smile', 'smith', 'smoke', 'snake',
      'snow', 'solid', 'solve', 'sorry', 'sound', 'south', 'space', 'spare', 'speak', 'speed',
      'spend', 'spent', 'split', 'spoke', 'sport', 'staff', 'stage', 'stake', 'stand', 'start',
      'state', 'steam', 'steel', 'steep', 'steer', 'stern', 'stick', 'still', 'stock', 'stone',
      'stood', 'store', 'storm', 'story', 'strip', 'stuck', 'study', 'stuff', 'style', 'sugar',
      'suite', 'super', 'sweet', 'swept', 'swift', 'swing', 'swiss', 'table', 'taken', 'taste',
      'taxes', 'teach', 'team', 'terry', 'texas', 'thank', 'theft', 'their', 'theme', 'there',
      'these', 'thick', 'thing', 'think', 'third', 'those', 'three', 'threw', 'throw', 'thumb',
      'tiger', 'tight', 'timer', 'tiny', 'title', 'today', 'token', 'topic', 'total', 'touch',
      'tough', 'tower', 'track', 'trade', 'train', 'treat', 'trend', 'trial', 'tribe', 'trick',
      'tried', 'tries', 'truck', 'truly', 'trunk', 'trust', 'truth', 'twice', 'uncle', 'under',
      'undue', 'union', 'unity', 'until', 'upper', 'upset', 'urban', 'usage', 'usual', 'valid',
      'value', 'video', 'virus', 'visit', 'vital', 'vocal', 'voice', 'waste', 'watch', 'water',
      'wheel', 'where', 'which', 'while', 'white', 'whole', 'whose', 'woman', 'women', 'world',
      'worry', 'worse', 'worst', 'worth', 'would', 'write', 'wrong', 'wrote', 'young', 'yours',
      'youth'
    ];

    if (query.isEmpty) return [];
    
    return commonWords
        .where((word) => word.toLowerCase().startsWith(query.toLowerCase()))
        .take(10)
        .toList();
  }
}